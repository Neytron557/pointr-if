| method | n | chamfer | fscore |
|---|---:|---:|---:|
| coarse | 150 | 0.044413 | 0.593049 |
| partial | 150 | 0.140238 | 0.272746 |
| refined | 150 | 0.044413 | 0.593048 |

| comparison | CD improvement vs coarse |
|---|---:|
| partial_vs_coarse_cd_percent | -215.7569% |
| refined_vs_coarse_cd_percent | -0.0000% |
