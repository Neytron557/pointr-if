from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Dict, Tuple

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
import yaml

from .datasets import make_dataset
from .models import build_model_from_config
from .point_ops import (
    chamfer_components,
    chamfer_distance,
    fscore,
    nearest_delta,
    partial_preservation_loss,
    repulsion_loss,
    sample_occupancy_queries,
    set_seed,
    to_device,
)


def load_config(path: str | Path) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if cfg is None:
        cfg = {}
    return cfg


def save_config(cfg: Dict, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)


def make_loaders(cfg: Dict) -> Tuple[DataLoader, DataLoader]:
    train_set = make_dataset(cfg, split="train")
    val_set = make_dataset(cfg, split="val")
    train_cfg = cfg.get("train", {})
    batch_size = int(train_cfg.get("batch_size", 4))
    num_workers = int(train_cfg.get("num_workers", 2))
    train_loader = DataLoader(
        train_set,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        drop_last=False,
    )
    val_loader = DataLoader(
        val_set,
        batch_size=int(train_cfg.get("val_batch_size", batch_size)),
        shuffle=False,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        drop_last=False,
    )
    return train_loader, val_loader


def compute_losses(model, batch: Dict, cfg: Dict) -> Tuple[torch.Tensor, Dict[str, float]]:
    loss_cfg = cfg.get("loss", {})
    partial = batch["partial"]
    coarse = batch["coarse"]
    gt = batch["gt"]
    qcfg = cfg.get("queries", {})
    query, occ_labels = sample_occupancy_queries(
        gt,
        n_query=int(qcfg.get("n_query", 512)),
        threshold=float(qcfg.get("threshold", 0.035)),
        near_ratio=float(qcfg.get("near_ratio", 0.65)),
        near_std=float(qcfg.get("near_std", 0.035)),
        box_scale=float(qcfg.get("box_scale", 1.25)),
    )
    out = model(partial=partial, coarse=coarse, query=query)
    refined = out["refined"]

    loss_cd = chamfer_distance(refined, gt, squared=bool(loss_cfg.get("squared_cd", False)))
    loss_occ = F.binary_cross_entropy_with_logits(out["occ_logits"], occ_labels)

    target_delta = nearest_delta(coarse, gt).detach()
    loss_delta = F.smooth_l1_loss(out["coarse_delta"], target_delta)
    loss_partial = partial_preservation_loss(refined, partial)
    loss_repulse = repulsion_loss(refined, k=int(loss_cfg.get("repulsion_k", 5)), radius=float(loss_cfg.get("repulsion_radius", 0.025)))

    total = (
        float(loss_cfg.get("lambda_cd", 1.0)) * loss_cd
        + float(loss_cfg.get("lambda_occ", 0.2)) * loss_occ
        + float(loss_cfg.get("lambda_delta", 0.5)) * loss_delta
        + float(loss_cfg.get("lambda_partial", 0.05)) * loss_partial
        + float(loss_cfg.get("lambda_repulsion", 0.0)) * loss_repulse
    )
    logs = {
        "loss": float(total.detach().cpu()),
        "loss_cd": float(loss_cd.detach().cpu()),
        "loss_occ": float(loss_occ.detach().cpu()),
        "loss_delta": float(loss_delta.detach().cpu()),
        "loss_partial": float(loss_partial.detach().cpu()),
        "loss_repulsion": float(loss_repulse.detach().cpu()),
    }
    return total, logs


def _avg(values):
    return sum(values) / max(1, len(values))


@torch.no_grad()
def evaluate(model, loader: DataLoader, cfg: Dict, device: torch.device, max_batches: int | None = None) -> Dict[str, float]:
    model.eval()
    rows = []
    f_threshold = float(cfg.get("eval", {}).get("fscore_threshold", 0.03))
    for i, batch in enumerate(loader):
        if max_batches is not None and i >= max_batches:
            break
        batch = to_device(batch, device)
        out = model(batch["partial"], batch["coarse"])
        refined = out["refined"]
        coarse = batch["coarse"]
        gt = batch["gt"]
        batch_n = int(gt.shape[0])
        coarse_components = chamfer_components(coarse, gt)
        refined_components = chamfer_components(refined, gt)
        coarse_cd = coarse_components["cd"]
        refined_cd = refined_components["cd"]
        coarse_f = fscore(coarse, gt, threshold=f_threshold)["fscore"]
        refined_f = fscore(refined, gt, threshold=f_threshold)["fscore"]
        rows.append({
            "coarse_cd_pred_to_gt": coarse_components["cd_pred_to_gt"],
            "coarse_cd_gt_to_pred": coarse_components["cd_gt_to_pred"],
            "coarse_cd": coarse_cd,
            "refined_cd_pred_to_gt": refined_components["cd_pred_to_gt"],
            "refined_cd_gt_to_pred": refined_components["cd_gt_to_pred"],
            "refined_cd": refined_cd,
            "coarse_fscore": coarse_f,
            "refined_fscore": refined_f,
            "n_samples": batch_n,
        })
    if not rows:
        return {
            "coarse_cd_pred_to_gt": math.nan,
            "coarse_cd_gt_to_pred": math.nan,
            "coarse_cd": math.nan,
            "refined_cd_pred_to_gt": math.nan,
            "refined_cd_gt_to_pred": math.nan,
            "refined_cd": math.nan,
            "coarse_fscore": math.nan,
            "refined_fscore": math.nan,
            "cd_improvement_pct": math.nan,
            "fscore_gain": math.nan,
            "n_samples": 0,
        }
    total_samples = sum(int(r["n_samples"]) for r in rows)
    metrics = {
        k: sum(float(r[k]) * int(r["n_samples"]) for r in rows) / max(1, total_samples)
        for k in rows[0].keys()
        if k != "n_samples"
    }
    metrics["cd_improvement_pct"] = 100.0 * (metrics["coarse_cd"] - metrics["refined_cd"]) / max(metrics["coarse_cd"], 1e-9)
    metrics["fscore_gain"] = metrics["refined_fscore"] - metrics["coarse_fscore"]
    metrics["n_samples"] = total_samples
    return metrics


def train(cfg: Dict, output_dir: str | Path) -> Dict[str, float]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    train_cfg = cfg.get("train", {})
    num_threads = int(train_cfg.get("num_threads", 4))
    if num_threads > 0:
        torch.set_num_threads(num_threads)
    set_seed(int(cfg.get("seed", 0)))
    device_str = cfg.get("train", {}).get("device", "cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device_str if device_str != "cuda" or torch.cuda.is_available() else "cpu")
    save_config(cfg, output_dir / "resolved_config.yaml")

    train_loader, val_loader = make_loaders(cfg)
    model = build_model_from_config(cfg).to(device)
    opt = torch.optim.AdamW(
        model.parameters(),
        lr=float(train_cfg.get("lr", 2e-4)),
        weight_decay=float(train_cfg.get("weight_decay", 1e-4)),
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(1, int(train_cfg.get("epochs", 50))))
    start_epoch = 0
    best_cd = float("inf")

    metrics_path = output_dir / "metrics.csv"
    metric_fields = [
        "epoch", "split", "loss", "loss_cd", "loss_occ", "loss_delta", "loss_partial", "loss_repulsion",
        "coarse_cd_pred_to_gt", "coarse_cd_gt_to_pred", "coarse_cd",
        "refined_cd_pred_to_gt", "refined_cd_gt_to_pred", "refined_cd",
        "cd_improvement_pct", "coarse_fscore", "refined_fscore", "fscore_gain", "n_samples", "lr"
    ]
    with metrics_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=metric_fields)
        writer.writeheader()

    epochs = int(train_cfg.get("epochs", 50))
    grad_clip = float(train_cfg.get("grad_clip", 1.0))
    log_every = int(train_cfg.get("log_every", 20))
    val_every = int(train_cfg.get("val_every", 1))
    max_val_batches = train_cfg.get("max_val_batches", None)
    max_val_batches = None if max_val_batches in (None, "null") else int(max_val_batches)

    last_val = {}
    for epoch in range(start_epoch, epochs):
        model.train()
        agg = []
        pbar = tqdm(train_loader, desc=f"epoch {epoch+1}/{epochs}", leave=False)
        for step, batch in enumerate(pbar):
            batch = to_device(batch, device)
            opt.zero_grad(set_to_none=True)
            loss, logs = compute_losses(model, batch, cfg)
            loss.backward()
            if grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            opt.step()
            agg.append(logs)
            if (step + 1) % log_every == 0 or step == 0:
                pbar.set_postfix({"loss": f"{logs['loss']:.4f}", "cd": f"{logs['loss_cd']:.4f}", "occ": f"{logs['loss_occ']:.4f}"})
        scheduler.step()
        train_logs = {k: _avg([r[k] for r in agg]) for k in agg[0].keys()}
        train_logs.update({"epoch": epoch + 1, "split": "train", "lr": scheduler.get_last_lr()[0]})

        with metrics_path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=metric_fields, extrasaction="ignore")
            writer.writerow(train_logs)

        if (epoch + 1) % val_every == 0 or epoch == epochs - 1:
            last_val = evaluate(model, val_loader, cfg, device=device, max_batches=max_val_batches)
            val_row = {"epoch": epoch + 1, "split": "val", "lr": scheduler.get_last_lr()[0], **last_val}
            with metrics_path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=metric_fields, extrasaction="ignore")
                writer.writerow(val_row)
            print(f"epoch {epoch+1}: val refined_cd={last_val['refined_cd']:.6f} coarse_cd={last_val['coarse_cd']:.6f} improvement={last_val['cd_improvement_pct']:.2f}%")
            if math.isfinite(last_val["refined_cd"]) and last_val["refined_cd"] < best_cd:
                best_cd = last_val["refined_cd"]
                torch.save({"model": model.state_dict(), "cfg": cfg, "epoch": epoch + 1, "metrics": last_val}, output_dir / "best_model.pt")
        torch.save({"model": model.state_dict(), "cfg": cfg, "epoch": epoch + 1, "metrics": last_val}, output_dir / "last_model.pt")

    summary = {"best_refined_cd": best_cd, "last_val": last_val, "output_dir": str(output_dir)}
    with (output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    return summary


def apply_overrides(cfg: Dict, args: argparse.Namespace) -> Dict:
    cfg = dict(cfg)
    cfg.setdefault("train", {})
    cfg.setdefault("loss", {})
    cfg.setdefault("model", {})
    cfg.setdefault("dataset", {})
    if args.epochs is not None:
        cfg["train"]["epochs"] = args.epochs
    if args.batch_size is not None:
        cfg["train"]["batch_size"] = args.batch_size
        cfg["train"]["val_batch_size"] = args.batch_size
    if args.lr is not None:
        cfg["train"]["lr"] = args.lr
    if args.device is not None:
        cfg["train"]["device"] = args.device
    if args.no_local:
        cfg["model"]["use_local"] = False
    if args.lambda_occ is not None:
        cfg["loss"]["lambda_occ"] = args.lambda_occ
    if args.dataset_type is not None:
        cfg["dataset"]["type"] = args.dataset_type
    if args.data_root is not None:
        cfg["dataset"]["root"] = args.data_root
    if args.manifest is not None:
        cfg["dataset"]["manifest"] = args.manifest
        cfg["dataset"]["type"] = "manifest"
    return cfg


def main() -> None:
    parser = argparse.ArgumentParser(description="Train PoinTr-IF implicit surface refiner")
    parser.add_argument("--config", default="configs/smoke_synthetic.yaml")
    parser.add_argument("--output-dir", default="outputs/train")
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--lr", type=float, default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--no-local", action="store_true", help="Ablation: global feature only, no local KNN features")
    parser.add_argument("--lambda-occ", type=float, default=None, help="Override occupancy loss weight")
    parser.add_argument("--dataset-type", default=None, choices=["synthetic", "npz", "h5", "manifest"])
    parser.add_argument("--data-root", default=None)
    parser.add_argument("--manifest", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    cfg = apply_overrides(cfg, args)
    summary = train(cfg, args.output_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
