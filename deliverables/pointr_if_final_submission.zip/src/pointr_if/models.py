from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import torch
from torch import nn
import torch.nn.functional as F


def mlp(channels, activation=nn.ReLU, final_activation: Optional[nn.Module] = None) -> nn.Sequential:
    layers = []
    for i in range(len(channels) - 1):
        layers.append(nn.Linear(channels[i], channels[i + 1]))
        if i != len(channels) - 2:
            layers.append(activation())
        elif final_activation is not None:
            layers.append(final_activation)
    return nn.Sequential(*layers)


class FourierFeatures(nn.Module):
    """Sin/cos positional encoding for 3D query points."""

    def __init__(self, num_bands: int = 6, include_xyz: bool = True):
        super().__init__()
        self.num_bands = int(num_bands)
        self.include_xyz = include_xyz
        if self.num_bands > 0:
            bands = 2.0 ** torch.arange(self.num_bands).float()
            self.register_buffer("bands", bands)
        else:
            self.register_buffer("bands", torch.empty(0))

    @property
    def out_dim(self) -> int:
        return (3 if self.include_xyz else 0) + 3 * 2 * self.num_bands

    def forward(self, xyz: torch.Tensor) -> torch.Tensor:
        outs = []
        if self.include_xyz:
            outs.append(xyz)
        if self.num_bands > 0:
            scaled = xyz.unsqueeze(-1) * self.bands  # [B,N,3,K]
            scaled = scaled.flatten(-2)  # [B,N,3K]
            outs.extend([torch.sin(torch.pi * scaled), torch.cos(torch.pi * scaled)])
        return torch.cat(outs, dim=-1)


@dataclass
class EncodedPointSet:
    base_points: torch.Tensor
    point_features: torch.Tensor
    global_feature: torch.Tensor


class PointSetEncoder(nn.Module):
    """Lightweight PointNet-style encoder for partial + coarse points.

    Each point gets a source flag: 0 for observed partial point, 1 for coarse
    completion point. The global max pooled code carries shape context; the per
    point features support local implicit queries.
    """

    def __init__(self, hidden_dim: int = 96, point_feature_dim: int = 96, global_dim: int = 192):
        super().__init__()
        self.point_mlp = mlp([4, hidden_dim, point_feature_dim, point_feature_dim])
        self.global_mlp = mlp([point_feature_dim, global_dim, global_dim])

    def forward(self, partial: torch.Tensor, coarse: torch.Tensor) -> EncodedPointSet:
        b = partial.shape[0]
        p_flag = torch.zeros(b, partial.shape[1], 1, device=partial.device, dtype=partial.dtype)
        c_flag = torch.ones(b, coarse.shape[1], 1, device=coarse.device, dtype=coarse.dtype)
        base = torch.cat([partial, coarse], dim=1)
        src = torch.cat([p_flag, c_flag], dim=1)
        point_in = torch.cat([base, src], dim=-1)
        feats = self.point_mlp(point_in)
        global_feat = feats.max(dim=1).values
        global_feat = self.global_mlp(global_feat)
        return EncodedPointSet(base_points=base, point_features=feats, global_feature=global_feat)


class ImplicitSurfaceRefiner(nn.Module):
    """Implicit occupancy + residual point refiner for PoinTr predictions.

    The model is trained with two compatible objectives:
      1. Predict occupancy / near-surface labels at arbitrary 3D query locations.
      2. Predict residual displacements for coarse PoinTr points, yielding a refined
         complete point cloud that can be evaluated directly with Chamfer distance.

    This keeps the proposal's implicit-function idea while staying feasible without
    watertight mesh occupancy labels.
    """

    def __init__(
        self,
        hidden_dim: int = 128,
        point_feature_dim: int = 96,
        global_dim: int = 192,
        fourier_bands: int = 6,
        k: int = 12,
        use_local: bool = True,
        delta_scale: float = 0.12,
    ):
        super().__init__()
        self.k = int(k)
        self.use_local = bool(use_local)
        self.delta_scale = float(delta_scale)
        self.encoder = PointSetEncoder(hidden_dim=hidden_dim, point_feature_dim=point_feature_dim, global_dim=global_dim)
        self.fourier = FourierFeatures(num_bands=fourier_bands, include_xyz=True)

        if self.use_local:
            self.local_mlp = mlp([point_feature_dim + 4, hidden_dim, hidden_dim])
            local_dim = hidden_dim
        else:
            local_dim = 0

        query_in_dim = self.fourier.out_dim + global_dim + local_dim
        self.query_trunk = mlp([query_in_dim, hidden_dim, hidden_dim, hidden_dim])
        self.occ_head = nn.Linear(hidden_dim, 1)
        self.delta_head = nn.Linear(hidden_dim, 3)

    def _local_features(self, query: torch.Tensor, encoded: EncodedPointSet) -> torch.Tensor:
        base = encoded.base_points
        feats = encoded.point_features
        k = min(max(self.k, 1), base.shape[1])
        d = torch.cdist(query, base, p=2)
        knn_d, idx = d.topk(k=k, dim=2, largest=False)

        idx_feat = idx.unsqueeze(-1).expand(-1, -1, -1, feats.shape[-1])
        feats_exp = feats.unsqueeze(1).expand(-1, query.shape[1], -1, -1)
        neigh_feats = feats_exp.gather(dim=2, index=idx_feat)

        idx_xyz = idx.unsqueeze(-1).expand(-1, -1, -1, 3)
        base_exp = base.unsqueeze(1).expand(-1, query.shape[1], -1, -1)
        neigh_xyz = base_exp.gather(dim=2, index=idx_xyz)
        rel = query.unsqueeze(2) - neigh_xyz
        inp = torch.cat([neigh_feats, rel, knn_d.unsqueeze(-1)], dim=-1)
        local_tokens = self.local_mlp(inp)
        weights = torch.softmax(-knn_d.clamp_min(1e-6), dim=2).unsqueeze(-1)
        return (local_tokens * weights).sum(dim=2)

    def query_field(self, query: torch.Tensor, partial: torch.Tensor, coarse: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        encoded = self.encoder(partial, coarse)
        return self.query_field_encoded(query, encoded)

    def query_field_encoded(self, query: torch.Tensor, encoded: EncodedPointSet) -> Tuple[torch.Tensor, torch.Tensor]:
        b, nq, _ = query.shape
        global_feat = encoded.global_feature.unsqueeze(1).expand(-1, nq, -1)
        query_feat = [self.fourier(query), global_feat]
        if self.use_local:
            query_feat.append(self._local_features(query, encoded))
        h = self.query_trunk(torch.cat(query_feat, dim=-1))
        occ_logits = self.occ_head(h).squeeze(-1)
        delta = torch.tanh(self.delta_head(h)) * self.delta_scale
        return occ_logits, delta

    def forward(
        self,
        partial: torch.Tensor,
        coarse: torch.Tensor,
        query: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        encoded = self.encoder(partial, coarse)
        coarse_occ, coarse_delta = self.query_field_encoded(coarse, encoded)
        refined = coarse + coarse_delta
        out = {"refined": refined, "coarse_delta": coarse_delta, "coarse_occ_logits": coarse_occ}
        if query is not None:
            occ_logits, query_delta = self.query_field_encoded(query, encoded)
            out.update({"occ_logits": occ_logits, "query_delta": query_delta})
        return out


def build_model_from_config(cfg: Dict) -> ImplicitSurfaceRefiner:
    model_cfg = cfg.get("model", cfg)
    return ImplicitSurfaceRefiner(
        hidden_dim=int(model_cfg.get("hidden_dim", 128)),
        point_feature_dim=int(model_cfg.get("point_feature_dim", 96)),
        global_dim=int(model_cfg.get("global_dim", 192)),
        fourier_bands=int(model_cfg.get("fourier_bands", 6)),
        k=int(model_cfg.get("k", 12)),
        use_local=bool(model_cfg.get("use_local", True)),
        delta_scale=float(model_cfg.get("delta_scale", 0.12)),
    )
