# PoinTr-IF: Geometry-Aware Point Cloud Completion with Implicit Surface Refinement

This package is a 2-2.5 day implementation plan and runnable codebase for a CS570 project that keeps the original proposal idea: use PoinTr/AdaPoinTr as a point-cloud completion backbone and add a lightweight implicit refinement module.

The implementation is intentionally **non-invasive**: it can train as a post-refinement module from `(partial point cloud, coarse PoinTr prediction, complete ground truth)` triplets. That makes it feasible to run quickly on a single 12 GB GPU while still addressing the professor's feedback about implicit point-cloud representations and the reason for using PoinTr.

## What is implemented

- `ImplicitSurfaceRefiner`: a PyTorch model that encodes partial + coarse complete point clouds, predicts an occupancy field for arbitrary query points, and predicts residual corrections for the coarse PoinTr points.
- Losses: Chamfer distance, occupancy/BCE pseudo-supervision from complete point clouds, nearest-neighbor residual loss, and optional partial-preservation loss.
- Datasets: synthetic point-cloud completion dataset for smoke tests, `.npz` triplet dataset, HDF5 triplet dataset, manifest-based dataset, and PCD/Numpy point-cloud IO utilities.
- Training/evaluation scripts: train the refiner, evaluate coarse vs refined completion, visualize qualitative outputs, and run ablations.
- Server-ready scripts for a single GPU workflow.
- Documentation explaining how the proposal should be reframed to answer the professor's feedback.

## Quick start: smoke test on CPU

```bash
cd pointr_if_project
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
bash scripts/run_smoke.sh
```

The smoke test trains on synthetic objects for a few epochs, evaluates coarse vs refined Chamfer/F-score metrics, and saves outputs under `outputs/smoke/`.

If your shell does not provide `python` until the virtual environment is active, use `python3 -m venv .venv` for the first line.

## Diagnostics and checks

```bash
source .venv/bin/activate
python scripts/doctor.py
bash scripts/test_imports.sh
pytest -q
bash scripts/run_smoke.sh
bash scripts/run_ablation_synthetic.sh
```

`scripts/doctor.py` reports Python, PyTorch, CUDA availability, `nvidia-smi` status, required imports, and expected project paths.

## Recommended 2-day project path

1. Use the official PoinTr repository and a pretrained PoinTr/AdaPoinTr checkpoint to generate coarse completions on a small PCN or ShapeNet-55 subset.
2. Convert `(partial, coarse, complete)` files into a triplet dataset using `tools/convert_pointr_predictions.py`, `tools/build_triplet_dataset.py`, or a CSV manifest.
3. Train this refiner for 30-80 epochs with `scripts/train_titanx.sh`.
4. Evaluate PoinTr vs PoinTr-IF with `scripts/evaluate_titanx.sh` and create qualitative visualizations.
5. Report the refiner as an implicit auxiliary module rather than a full Occupancy Network replacement.

Expected real-data manifest:

```csv
id,partial,coarse,gt
chair_0001,/abs/path/partial.pcd,/abs/path/pointr_pred.pcd,/abs/path/complete.pcd
```

Adapter and validation commands:

```bash
python tools/convert_pointr_predictions.py \
  --partial-dir /path/to/partial \
  --coarse-dir /path/to/pointr_predictions \
  --gt-dir /path/to/complete_gt \
  --output-manifest data/manifests/pcn_train_triplets.csv \
  --split train \
  --limit 1000

python tools/validate_triplet_manifest.py data/manifests/pcn_train_triplets.csv --max-samples 5
python tools/validate_triplet_manifest.py data/manifests/pcn_val_triplets.csv --max-samples 5
```

The loader and adapter support `.npy`, `.npz`, `.pcd`, `.txt`, `.xyz`, `.h5`, and `.hdf5` point-cloud files when the file contains an obvious `[N, 3]` or `[B, N, 3]` point array.

## Current verified status

The current repository passes packaging, import, unit, smoke, ablation, adapter, and manifest validation checks in this CPU-only environment. The official PoinTr repository has been cloned under `external/PoinTr`, but no real PCN/ShapeNet data or pretrained PoinTr/AdaPoinTr checkpoints are present here, and CUDA is not available. Synthetic metrics are useful only as smoke-test evidence and should not be reported as real benchmark improvements.

See `docs/IMPLEMENTATION_PLAN.md` and `docs/PROFESSOR_FEEDBACK_RESPONSE.md` for the full project plan.

## Documentation map

- `docs/UPLOADED_PROPOSAL_ANALYSIS.md`: analysis of the uploaded proposal, feedback, and slides.
- `docs/PROFESSOR_FEEDBACK_RESPONSE.md`: how to address the professor's three critical comments.
- `docs/IMPLEMENTATION_PLAN.md`: 2-2.5 day implementation strategy and experiment matrix.
- `docs/SERVER_RUNBOOK.md`: step-by-step server/GPU run guide.
- `docs/EXPERIMENT_LOG.md`: smoke/ablation results already run in this package.
- `docs/CODEX_STATUS.md`: latest environment, commands, blockers, and next actions.
- `docs/FINAL_REPORT_TEMPLATE.md`: structure for the final course report.
- `docs/REFERENCES.md`: papers to cite.
