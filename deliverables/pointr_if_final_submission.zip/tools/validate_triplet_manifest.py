#!/usr/bin/env python
"""Validate a PoinTr-IF triplet manifest before training."""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, List

import numpy as np

# Allow running from a fresh checkout before editable install.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from pointr_if.io import load_point_cloud, read_manifest


REQUIRED_COLUMNS = {"id", "partial", "coarse", "gt"}


def _stats(points: np.ndarray) -> Dict[str, Any]:
    arr = np.asarray(points, dtype=np.float32)
    finite = np.isfinite(arr)
    return {
        "shape": list(arr.shape),
        "finite": bool(finite.all()),
        "nan_count": int(np.isnan(arr).sum()),
        "inf_count": int(np.isinf(arr).sum()),
        "min": float(np.nanmin(arr)) if arr.size else math.nan,
        "max": float(np.nanmax(arr)) if arr.size else math.nan,
    }


def _read_header(path: Path) -> List[str]:
    with path.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or [])


def validate_manifest(path: str | Path, max_samples: int = 5) -> Dict[str, Any]:
    manifest = Path(path)
    header = _read_header(manifest)
    missing_columns = sorted(REQUIRED_COLUMNS - set(header))
    if missing_columns:
        raise ValueError(f"Manifest {manifest} is missing columns: {missing_columns}; found {header}")

    rows = read_manifest(manifest)
    summary: Dict[str, Any] = {
        "manifest": str(manifest),
        "n_rows": len(rows),
        "checked_rows": 0,
        "missing_files": [],
        "samples": [],
    }
    for row_index, row in enumerate(rows[: max(0, max_samples)]):
        sample: Dict[str, Any] = {"row_index": row_index, "id": row.get("id", "")}
        for key in ("partial", "coarse", "gt"):
            cloud_path = Path(row[key])
            if not cloud_path.exists():
                summary["missing_files"].append({"row_index": row_index, "id": row.get("id", ""), "field": key, "path": str(cloud_path)})
                continue
            points = load_point_cloud(cloud_path)
            if points.ndim != 2 or points.shape[1] < 3 or points.shape[0] == 0:
                raise ValueError(f"{key} for row {row_index} must be non-empty [N, >=3], got {points.shape}: {cloud_path}")
            stats = _stats(points[:, :3])
            if not stats["finite"]:
                raise ValueError(f"{key} for row {row_index} contains NaN/Inf values: {cloud_path}")
            sample[key] = {"path": str(cloud_path), **stats}
        summary["samples"].append(sample)
        summary["checked_rows"] += 1

    if summary["missing_files"]:
        raise FileNotFoundError(f"Manifest has {len(summary['missing_files'])} missing files")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate a PoinTr-IF CSV manifest")
    parser.add_argument("manifest")
    parser.add_argument("--max-samples", type=int, default=5)
    parser.add_argument("--json-out", default=None, help="Optional path for a JSON validation summary")
    args = parser.parse_args()

    summary = validate_manifest(args.manifest, max_samples=args.max_samples)
    print(json.dumps(summary, indent=2))
    if args.json_out:
        out = Path(args.json_out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
