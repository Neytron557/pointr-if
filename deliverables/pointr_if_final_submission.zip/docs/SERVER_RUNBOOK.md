# Server Runbook

Target server described by the team:

- 32 vCPU
- ~100 GB RAM
- NVIDIA GP102/TITAN X class GPU, typically 12 GB VRAM
- ~94 GB free disk
- Current warning: NVIDIA drivers may not be installed/active.

## 1. Verify GPU

```bash
nvidia-smi
```

If this fails, install/activate NVIDIA drivers before attempting CUDA training. PyTorch cannot use the TITAN X until `nvidia-smi` works.

## 2. Install this project

```bash
cd pointr_if_project
bash scripts/setup_server.sh
```

## 3. Install official PoinTr

Use a separate folder:

```bash
git clone https://github.com/yuxumin/PoinTr.git ~/PoinTr
cd ~/PoinTr
pip install -r requirements.txt
bash install.sh
pip install "git+https://github.com/erikwijmans/Pointnet2_PyTorch.git#egg=pointnet2_ops&subdirectory=pointnet2_ops_lib"
pip install --upgrade https://github.com/unlimblue/KNN_CUDA/releases/download/0.2/KNN_CUDA-0.2-py3-none-any.whl
```

Download PoinTr or AdaPoinTr checkpoints and the PCN dataset following the official repo instructions.

## 4. Generate coarse predictions

The exact command depends on where the checkpoint and partial files are stored. A template is in:

```bash
scripts/pointr_baseline_commands.sh
```

For a fast project, generate predictions for a subset first, not the entire dataset.

## 5. Build a manifest

Create `data/manifests/pcn_train_triplets.csv` and `data/manifests/pcn_val_triplets.csv` with columns:

```csv
id,partial,coarse,gt
chair_0001,/abs/path/partial.pcd,/abs/path/coarse.pcd,/abs/path/complete.pcd
```

You can use:

```bash
python tools/convert_pointr_predictions.py \
  --partial-dir /path/to/partial \
  --coarse-dir /path/to/coarse_predictions \
  --gt-dir /path/to/complete \
  --output-manifest data/manifests/pcn_val_triplets.csv \
  --split val \
  --limit 200
```

or the simpler root matcher:

```bash
python tools/build_triplet_dataset.py manifest \
  --partial-root /path/to/partial \
  --coarse-root /path/to/coarse_predictions \
  --gt-root /path/to/complete \
  --out-csv data/manifests/pcn_val_triplets.csv \
  --match basename
```

If automatic matching does not work because PCN partial views have nested names, manually create the CSV or adjust filenames.

Validate before training:

```bash
python tools/validate_triplet_manifest.py data/manifests/pcn_train_triplets.csv --max-samples 5
python tools/validate_triplet_manifest.py data/manifests/pcn_val_triplets.csv --max-samples 5
```

## 6. Train

Fast first run:

```bash
CUDA_VISIBLE_DEVICES=0 bash scripts/train_titanx.sh configs/titanx_fast_subset.yaml outputs/titanx_fast
```

Longer main run:

```bash
CUDA_VISIBLE_DEVICES=0 bash scripts/train_titanx.sh configs/titanx_pcn_refiner.yaml outputs/titanx_main
```

If out of memory, reduce in the YAML:

- `train.batch_size`: 4 -> 2
- `queries.n_query`: 2048 -> 1024 or 512
- `dataset.n_coarse/n_gt/n_partial`: 2048 -> 1024
- `model.k`: 12 -> 8

## 7. Evaluate and visualize

```bash
CUDA_VISIBLE_DEVICES=0 bash scripts/evaluate_titanx.sh outputs/titanx_main/best_model.pt outputs/titanx_eval
```

Key files:

- `outputs/titanx_eval/val_summary.json`
- `outputs/titanx_eval/val_per_sample_metrics.csv`
- `outputs/titanx_eval/visuals/*.png`

## 8. Report numbers

Report:

- Coarse PoinTr CD/F-score.
- Refined PoinTr-IF CD/F-score.
- Percent CD improvement.
- Category or difficulty breakdown if available.
- Ablations: local+global vs global-only; with occupancy vs no occupancy.
