# Final Report Template

## Title

PoinTr-IF: Geometry-Aware Point Cloud Completion with Implicit Surface Refinement

## Abstract

We investigate whether an implicit surface refinement head can improve PoinTr-style point-cloud completion. PoinTr predicts a finite set of complete points from a partial observation. Our method adds a lightweight implicit decoder conditioned on partial and coarse predicted points. The decoder is trained with pseudo near-surface occupancy queries and point residual refinement losses. This keeps the method feasible for point-cloud-only datasets while introducing continuous surface supervision.

## Motivation

Point-cloud completion is often evaluated with point-set distances, but point-only losses do not explicitly model the continuous surface. This may lead to holes, noisy regions, or poor thin structures. An implicit decoder can query arbitrary 3D locations and learn a continuous near-surface signal, which may help refine hard missing regions.

## Related Work

Discuss:

- PointNet and PointNet++ as point-cloud encoders.
- Occupancy Networks as implicit function foundations.
- IF-Net and Convolutional Occupancy Networks as implicit representations conditioned on local 3D features.
- PoinTr/AdaPoinTr as completion-specific transformer baselines.
- SnowflakeNet/SeedFormer as point-completion methods focused on local detail.

## Method

Inputs:

```text
partial P, coarse completion C from PoinTr/AdaPoinTr, ground truth G
```

Model:

```text
feature encoder: concat(P, C, source flag) -> local point features + global shape code
implicit decoder: query q -> occupancy logit and residual delta
output: C_refined = C + delta(C)
```

Loss:

```text
Chamfer(C_refined, G)
+ occupancy BCE on sampled query points
+ nearest-neighbor residual loss
+ partial preservation loss
+ optional repulsion/uniformity loss
```

## Experiments

Datasets:

- PCN or ShapeNet-55/34 subset.
- Optional KITTI as qualitative generalization.

Baselines:

- PoinTr pretrained.
- AdaPoinTr pretrained as stronger reference if time allows.

Ablations:

- Local+global implicit conditioning.
- Global-only conditioning.
- No occupancy loss.

Metrics:

- Chamfer distance.
- F-score.
- Qualitative visualizations.
- Hard missing-region subset.

## Results

Current results from this CPU environment are synthetic smoke/ablation results only, not PCN/ShapeNet benchmark results. The real-data run was blocked by missing CUDA visibility, missing PCN/ShapeNet files, and missing PoinTr/AdaPoinTr checkpoint files.

Synthetic validation table:

| Method | CD lower better | F-score higher better | Notes |
|---|---:|---:|---|
| Coarse synthetic baseline | 0.13639 | 0.38220 | generated noisy coarse completion |
| PoinTr-IF global-only | 0.13434 | 0.39028 | ablation without local KNN features |
| PoinTr-IF no occupancy | 0.13342 | 0.39102 | ablation with `lambda_occ=0` |
| PoinTr-IF local+occupancy | 0.13360 | 0.39174 | main method |
| AdaPoinTr reference | not run | not run | requires checkpoint/data |

Real PCN/ShapeNet table to fill after server run:

| Method | CD lower better | F-score higher better | Dataset/subset | Notes |
|---|---:|---:|---|---|
| PoinTr baseline | | | | |
| PoinTr-IF global-only | | | | |
| PoinTr-IF no occupancy | | | | |
| PoinTr-IF local+occupancy | | | | |
| AdaPoinTr reference | | | | optional |

## Discussion

For the synthetic validation, all refiner variants improved Chamfer distance and F-score over the generated coarse input. The no-occupancy variant had the lowest synthetic Chamfer distance, while the local+occupancy model had the best synthetic F-score. This is not enough to claim real benchmark improvement; it only shows that the implementation and ablation machinery are working.

For real PCN/ShapeNet experiments, discuss whether the implicit head improves overall metrics or mainly hard cases. If results are mixed, explain that pseudo occupancy from point clouds is weaker than true mesh occupancy, and future work should use watertight meshes or end-to-end PoinTr feature integration.

## Conclusion

We kept the original proposal's core idea but made it feasible under the project deadline by using an implicit post-refinement module. The project demonstrates how continuous implicit supervision can be attached to point-cloud completion models while retaining standard point-set evaluation.
