# Codex Status

**Last updated:** 2026-05-30

## Environment Summary

- Project root: `/home/ubuntu/ai_and_ml/pointr_if_project`
- Python: 3.12.3 in `.venv`
- PyTorch: 2.12.0+cu130
- CUDA available to PyTorch: `false`
- `nvidia-smi`: not found on `PATH`
- Git status for this package: no `.git` repository is present in `pointr_if_project`
- Disk at project check time: 96 GB filesystem, 83 GB available

## PoinTr / Data Availability

- Official PoinTr repository was cloned to `external/PoinTr`.
- Cloned PoinTr commit: `3f98676`.
- No PCN, ShapeNet, or PoinTr/AdaPoinTr checkpoint files were found locally.
- Real PoinTr/AdaPoinTr subset experiments are blocked in this environment by missing CUDA/GPU driver visibility, missing dataset files, and missing checkpoint files.

## Commands Run

```bash
pwd
ls -la
find . -maxdepth 3 -type f | sort | sed 's#^./##' | head -200
git status --short || true
python --version || true
nvidia-smi || true
python3 --version || true
.venv/bin/python --version || true
```

Result: project root inspected; `python` was not globally available until venv activation; `nvidia-smi` unavailable.

```bash
python3 -m venv .venv || true
source .venv/bin/activate || true
python -m pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
bash scripts/test_imports.sh
pytest -q
```

Initial result: package installed and import smoke passed, but `pytest` was missing from `requirements.txt`; fixed by adding `pytest>=8.0`.

```bash
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
```

Result: passed, `5 passed in 7.27s` after adding the batched `.npz` loader test.

```bash
source .venv/bin/activate
python scripts/doctor.py
bash scripts/test_imports.sh
bash scripts/run_smoke.sh
```

Result: passed. `doctor.py` reported CPU-only execution; smoke train/eval/visualization completed.

```bash
source .venv/bin/activate
pytest -q
bash scripts/run_ablation_synthetic.sh
```

Result: passed. Synthetic ablation summaries were written to `outputs/ablation_synthetic/summary_table.csv` and `.md`.

```bash
source .venv/bin/activate
python tools/convert_pointr_predictions.py \
  --partial-dir data/tiny_manifest_sources/partial \
  --coarse-dir data/tiny_manifest_sources/coarse \
  --gt-dir data/tiny_manifest_sources/gt \
  --output-manifest data/manifests/tiny_val_triplets.csv \
  --split val \
  --limit 3 \
  --converted-root data/tiny_manifest_converted/val
python tools/validate_triplet_manifest.py \
  data/manifests/tiny_val_triplets.csv \
  --max-samples 3 \
  --json-out outputs/final_summary/tiny_manifest_validation.json
```

Result: passed. Three tiny triplets were converted and validated; all loaded arrays were finite.

```bash
source .venv/bin/activate
bash scripts/evaluate_titanx.sh \
  outputs/smoke/local_occ/best_model.pt \
  outputs/smoke/local_occ/titanx_eval_script
```

Result: passed. The wrapper requested CUDA but the evaluator/visualizer fell back to CPU and wrote metrics plus 16 qualitative PNG/PCD outputs.

```bash
source .venv/bin/activate
python scripts/summarize_runs.py outputs/ablation_synthetic/*/summary.json \
  --out outputs/final_summary/summary_table.csv \
  --markdown-out outputs/final_summary/summary_table.md
```

Result: passed.

```bash
zip -r deliverables/pointr_if_final_submission.zip \
  README.md Makefile pyproject.toml requirements.txt \
  configs docs scripts src tests tools \
  outputs/final_summary \
  -x '*.git*' '__pycache__/*' '*.pyc' '.venv/*'
```

Result: failed because `zip` is not installed in this environment. A Python `zipfile` fallback created `deliverables/pointr_if_final_submission.zip` with 50 files.

## Best Actual Metrics Run Here

These are synthetic smoke/ablation metrics only. They are not PCN or ShapeNet benchmark results.

| Run | Coarse CD | Refined CD | CD improvement | Coarse F-score | Refined F-score | F-score gain |
|---|---:|---:|---:|---:|---:|---:|
| global_only | 0.136394 | 0.134335 | 1.51% | 0.382204 | 0.390284 | +0.008080 |
| local_occ | 0.136394 | 0.133602 | 2.05% | 0.382204 | 0.391742 | +0.009538 |
| no_occ | 0.136394 | 0.133419 | 2.18% | 0.382204 | 0.391020 | +0.008816 |

The separate smoke checkpoint evaluation over 16 validation samples produced:

| Metric | Coarse | Refined |
|---|---:|---:|
| Chamfer distance | 0.136394 | 0.133602 |
| F-score @ 0.05 | 0.381128 | 0.390833 |

## Current Blockers

- CUDA/GPU cannot be verified because `nvidia-smi` is unavailable and PyTorch reports no CUDA device.
- Real PCN/ShapeNet subset manifests do not exist because no dataset files are present.
- Real PoinTr/AdaPoinTr coarse outputs do not exist because no pretrained checkpoint files are present.

## Next Actions

1. On the GPU server, make `nvidia-smi` work and install official PoinTr CUDA extensions.
2. Download the PCN or ShapeNet subset and a PoinTr/AdaPoinTr checkpoint using the official PoinTr instructions.
3. Generate coarse predictions, then build manifests with `tools/convert_pointr_predictions.py`.
4. Validate manifests with `tools/validate_triplet_manifest.py`.
5. Run `configs/titanx_fast_subset.yaml`, then run global-only or no-occupancy ablations on the same split.
