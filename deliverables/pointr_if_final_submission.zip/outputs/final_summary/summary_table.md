| Run | Best refined CD | Coarse CD | Refined CD | CD improvement % | Coarse F-score | Refined F-score | F-score gain | N | Checkpoint |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| global_only | 0.134335 | 0.136394 | 0.134335 | 1.50909 | 0.382204 | 0.390284 | 0.00807997 | 16 | outputs/ablation_synthetic/global_only/best_model.pt |
| local_occ | 0.133602 | 0.136394 | 0.133602 | 2.04703 | 0.382204 | 0.391742 | 0.0095378 | 16 | outputs/ablation_synthetic/local_occ/best_model.pt |
| no_occ | 0.133419 | 0.136394 | 0.133419 | 2.18129 | 0.382204 | 0.39102 | 0.00881586 | 16 | outputs/ablation_synthetic/no_occ/best_model.pt |
