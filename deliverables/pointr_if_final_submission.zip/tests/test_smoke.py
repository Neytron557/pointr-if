import torch
from torch.utils.data import DataLoader

from pointr_if.datasets import SyntheticCompletionDataset
from pointr_if.models import ImplicitSurfaceRefiner
from pointr_if.point_ops import chamfer_distance, sample_occupancy_queries


def test_forward_shapes():
    dset = SyntheticCompletionDataset(num_samples=2, n_partial=16, n_coarse=32, n_gt=32, seed=0)
    batch = next(iter(DataLoader(dset, batch_size=2)))
    model = ImplicitSurfaceRefiner(hidden_dim=16, point_feature_dim=12, global_dim=24, fourier_bands=2, k=4)
    query, labels = sample_occupancy_queries(batch["gt"].float(), n_query=10)
    out = model(batch["partial"].float(), batch["coarse"].float(), query.float())
    assert out["refined"].shape == batch["coarse"].shape
    assert out["occ_logits"].shape == labels.shape
    assert torch.isfinite(chamfer_distance(out["refined"], batch["gt"].float()))
